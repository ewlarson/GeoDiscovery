import{b as e}from"./pako.esm-BSHzuB9t-DQSVoCko.js";import{g as o}from"./basedecoder-PFIibI7U-gdlnpIMU.js";class f extends o{decodeBlock(r){return e(new Uint8Array(r)).buffer}}export{f as default};
