import{O as e}from"./index-pmp42xxj-DHbdtNrf.js";document.addEventListener("DOMContentLoaded",()=>{new e().run()});
